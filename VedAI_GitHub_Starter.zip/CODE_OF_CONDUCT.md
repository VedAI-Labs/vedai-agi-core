# Code of Conduct

Ved AI is committed to a safe, inclusive, and open community.
- Be respectful, welcoming, and collaborative.
- Harassment, discrimination, or toxicity will not be tolerated.
- We are building AGI for humanity—let's act like it.
