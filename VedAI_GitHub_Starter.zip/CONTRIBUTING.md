# Contributing to Ved AI AGI Lab

Welcome! We value your ideas, code, and questions. To contribute:
1. Fork this repo, make your change, open a Pull Request.
2. Open issues for ideas, bugs, or project suggestions.
3. Respect our Code of Conduct—collaboration is our superpower.

Docs, code, and insights from all backgrounds are welcomed!
